package com.syrianlira.calculator;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    // The only remote exchange-rate data host used by the app.
    private static final String SOURCE = "https://sp-today.com/currencies";
    private static final long REFRESH_INTERVAL_MS = 30_000L;
    private static final int MAX_HTML_BYTES = 2_500_000;

    private WebView webView;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();
    private final AtomicBoolean fetching = new AtomicBoolean(false);
    private boolean isActive = false;
    private boolean isDestroyed = false;

    private final Runnable refreshLoop = new Runnable() {
        @Override public void run() {
            if (!isActive || isDestroyed) return;
            requestRates();
            mainHandler.postDelayed(this, REFRESH_INTERVAL_MS);
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(7, 19, 33));
        getWindow().setNavigationBarColor(Color.rgb(7, 19, 33));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(7, 19, 33));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.addJavascriptInterface(new UiBridge(), "CurrencyHost");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !"file".equals(request.getUrl().getScheme());
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onResume() {
        super.onResume();
        isActive = true;
        mainHandler.removeCallbacks(refreshLoop);
        // The web UI starts the first refresh on DOM ready.
        mainHandler.postDelayed(refreshLoop, REFRESH_INTERVAL_MS);
    }

    @Override protected void onPause() {
        isActive = false;
        mainHandler.removeCallbacks(refreshLoop);
        super.onPause();
    }

    @Override protected void onDestroy() {
        isDestroyed = true;
        mainHandler.removeCallbacks(refreshLoop);
        networkExecutor.shutdownNow();
        if (webView != null) {
            webView.removeJavascriptInterface("CurrencyHost");
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    private final class UiBridge {
        @JavascriptInterface public void refresh() { requestRates(); }
        @JavascriptInterface public String cachedRates() {
            return getPreferences(MODE_PRIVATE).getString("last_valid_rates", "");
        }
        @JavascriptInterface public void openSource() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://sp-today.com/currencies"));
                startActivity(intent);
            });
        }
    }

    private void requestRates() {
        if (isDestroyed || !fetching.compareAndSet(false, true)) return;
        mainHandler.post(() -> js("window.appRateLoading && window.appRateLoading()"));
        networkExecutor.execute(() -> {
            try {
                String raw = fetchHtml(SOURCE);
                RatePair usd = findTableRate(raw, "USD");
                RatePair turkish = findTableRate(raw, "TRY");
                if (usd == null || turkish == null) {
                    throw new IllegalStateException("Rate table unavailable or changed");
                }
                JSONObject json = new JSONObject();
                json.put("usdBuy", usd.buy);
                json.put("usdSell", usd.sell);
                json.put("tryBuy", turkish.buy);
                json.put("trySell", turkish.sell);
                json.put("checkedAt", System.currentTimeMillis());
                json.put("source", "https://sp-today.com/currencies");
                final String encoded = json.toString();
                getPreferences(MODE_PRIVATE).edit().putString("last_valid_rates", encoded).apply();
                mainHandler.post(() -> js("window.onAppRates(" + encoded + ")"));
            } catch (Exception ex) {
                // Show a disconnected state, never a fabricated or silently freshened price.
                mainHandler.post(() -> js("window.onAppRatesFailure()"));
            } finally {
                fetching.set(false);
            }
        });
    }

    private void js(String code) {
        if (!isDestroyed && webView != null) webView.evaluateJavascript(code, null);
    }

    private static String fetchHtml(String address) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        try {
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(10000);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36");
            connection.setRequestProperty("Accept", "text/html,application/xhtml+xml");
            connection.setRequestProperty("Accept-Language", "ar,en;q=0.8");
            connection.setRequestProperty("Accept-Encoding", "identity");
            connection.setRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate");
            connection.setRequestProperty("Pragma", "no-cache");
            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new IllegalStateException("Site response not OK");
            }
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (InputStream in = connection.getInputStream()) {
                byte[] buf = new byte[8192];
                int len;
                while ((len = in.read(buf)) != -1) {
                    if (bytes.size() + len > MAX_HTML_BYTES) throw new IllegalStateException("HTML too large");
                    bytes.write(buf, 0, len);
                }
            }
            return bytes.toString(StandardCharsets.UTF_8.name());
        } finally { connection.disconnect(); }
    }

    private static final class RatePair {
        final double buy, sell;
        RatePair(double b, double s) { buy = b; sell = s; }
    }

    // Parse the site's publicly displayed <tr> cells; no third-party FX feed or rate guessing.
    // Validate old/new correspondence to guard against accidentally reading other numbers.
    private static RatePair findTableRate(String html, String iso) {
        String cleaned = html.replaceAll("(?is)<script\\b[^>]*>.*?</script>", " ")
                .replaceAll("(?is)<style\\b[^>]*>.*?</style>", " ");
        Matcher tableRows = Pattern.compile("(?is)<tr\\b[^>]*>(.*?)</tr>").matcher(cleaned);
        while (tableRows.find()) {
            String row = tableRows.group(1)
                    .replaceAll("(?is)<[^>]+>", " ")
                    .replace("&nbsp;", " ")
                    .replace("&#160;", " ")
                    .replaceAll("\\s+", " ").trim();
            Matcher matchIso = Pattern.compile("(?<![A-Z])" + iso + "(?![A-Z])").matcher(row);
            if (!matchIso.find()) continue;
            String body = row.substring(matchIso.end());
            // Exchange rows show new amount, old amount, new amount, old amount.
            Matcher num = Pattern.compile("(?<![\\p{L}\\d])\\d[\\d,.]*").matcher(body);
            double[] values = new double[4];
            int count = 0;
            while (num.find() && count < 4) {
                try { values[count++] = Double.parseDouble(num.group().replace(",", "")); }
                catch (NumberFormatException ignored) { return null; }
            }
            if (count != 4) continue;
            if (!body.contains("قديمة") && !body.toLowerCase().contains("old")) continue;
            double buyNew = values[0], buyOld = values[1], sellNew = values[2], sellOld = values[3];
            if (!(buyNew > 0 && sellNew > 0 && buyNew <= sellNew)) continue;
            if (Math.abs(100 * buyNew - buyOld) > Math.max(1, buyNew * 0.015)) continue;
            if (Math.abs(100 * sellNew - sellOld) > Math.max(1, sellNew * 0.015)) continue;
            if ("USD".equals(iso) && buyNew < 10) continue;
            return new RatePair(buyNew, sellNew);
        }
        // Some site versions render currency listings as divs rather than table rows.
        String visible = cleaned.replaceAll("(?is)<[^>]+>", " ")
                .replace("&nbsp;", " ").replace("&#160;", " ")
                .replaceAll("\\s+", " ").trim();
        Matcher code = Pattern.compile("(?<![A-Z])" + iso + "(?![A-Z])").matcher(visible);
        int probes = 0;
        while (code.find() && probes++ < 10) {
            String passage = visible.substring(code.end(), Math.min(visible.length(), code.end() + 210));
            Matcher number = Pattern.compile("(?<![\\p{L}\\d])\\d[\\d,.]*").matcher(passage);
            double[] q = new double[4];
            int n = 0;
            while (number.find() && n < 4) {
                try { q[n++] = Double.parseDouble(number.group().replace(",", "")); }
                catch (NumberFormatException ignored) { break; }
            }
            if (n != 4 || !passage.contains("قديمة")) continue;
            if (q[0] > 0 && q[2] >= q[0] &&
                Math.abs(q[1]-q[0]*100) <= Math.max(1, q[0]*0.015) &&
                Math.abs(q[3]-q[2]*100) <= Math.max(1, q[2]*0.015) &&
                (!"USD".equals(iso) || q[0] > 10)) return new RatePair(q[0], q[2]);
        }
        return null;
    }
}
